<?php


define('host', 'localhost');
define('password', '');
define('username', 'root');
define('dbName', 'onlineShopping');
define('USD','$');
define('EGY','e£');
