<?php

require_once("../models/productDao.php");

class ProductController{
   //function takes list of all items ans returns each item with it's quantities as associative array
   public function getPurchases($listPurchases)
   {   $purchase=array();
       if($listPurchases["T-shirt"]!=0)
       {
           $purchase['T-shirt']=$listPurchases["T-shirt"];
       }
       if($listPurchases["Jacket"]!=0)
       {
           $purchase['Jacket']=$listPurchases["Jacket"];
       }
       if($listPurchases["Shoes"]!=0)
       {
           $purchase['Shoes']=$listPurchases["Shoes"];
       }
       if($listPurchases["Pants"]!=0)
       {
           $purchase['Pants']=$listPurchases["Pants"];
       }
       return $purchase;
   }
   
   
   
   //function takes list of items and it's quantities and selected currency an return the subtotal without any additions 
   public function calcSubTotal($purchasesList,$currency)
   {
      $subtotal=0;
      foreach($purchasesList as $productType=>$quantity)
      {
          $itemPrice=0;
          $product=new ProductDao();
          $itemPrice=$product->getPrice($productType,$currency);
          $itemPrice*=$quantity;
          $subtotal+=$itemPrice;
      } 
      return $subtotal;
   }
   //function returns taxex
   public function calcTaxes($subtotal)
   {
       $taxes=.14*$subtotal;
       return $taxes;
   }
   
   //function search for item in purchased array if found returns its quantity else returns false
   public function searchForItem($purchases,$item)
   {
          foreach($purchases as $productType=>$quantity)
          {
              if($productType==$item)
              {
                  return $quantity;
              }
          }
          return false;
   }
   
   //function takes list of purchases from getAllProduct() function and calculate discounts if exist then returns the type of discount with its amount 
   public function showDiscounts($purchases,$currency)
   {   
       $discounts=array();
       $product=new ProductDao();  
       foreach($purchases as $productType=>$quantity)
       {           
              
           if($productType=="Shoes")
           {   
                //instantiate object from ProductDao Model
                
                for($i=0 ; $i<$quantity ; $i++)
                {  
                   $discounts['10% off shoes '.($i+1).':']=-.10*($product->getPrice($productType,$currency));
                }
           }
           if($productType=="Jacket")
           {    
               
               if($tshirt_quant=$this->searchForItem($purchases,"T-shirt"))
               {
                     $temp=$quantity;  
               for($i=0 ; $i<$quantity ; $i++)
                {
                   if($tshirt_quant>=$temp && $tshirt_quant>=2)
                   { 
                      $tshirt_quant-=2;
                      $temp--;
                      $discounts['50% off Jacket '.($i+1).': ']=-.50*($product->getPrice($productType,$currency));
                   }
                }
               }
           }
           
       }
       return $discounts;
   }
    //calculate total amount of discounts 
   public function calcDiscounts($discounts)
   {     $total_discounts=0;
       foreach($discounts as $discountType=>$amount)
       {
          $total_discounts+=$amount; 
       }
       return $total_discounts;
   }
  
  //calculate total price with taxes and discounts 
   public function calcTotal($subtotal,$taxses,$discounts)
   {
        $total=0;
        $total_discounts=$this->calcDiscounts($discounts);
        $total=$subtotal+$taxses+$total_discounts;
        
        return $total;
   }
   
   

}