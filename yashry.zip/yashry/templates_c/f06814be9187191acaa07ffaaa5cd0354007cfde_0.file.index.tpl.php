<?php
/* Smarty version 3.1.34-dev-7, created on 2020-10-31 01:18:23
  from 'C:\xampp\htdocs\yashry\views\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f9cad4f52bad5_44891614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f06814be9187191acaa07ffaaa5cd0354007cfde' => 
    array (
      0 => 'C:\\xampp\\htdocs\\yashry\\views\\index.tpl',
      1 => 1604103494,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f9cad4f52bad5_44891614 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="./public/css/style.css">
<title></title>
</head>
<body>



 <div class="container" ">
 
<form method="POST" action="views/route.php?action=getbill">
 <div>
 <label>Select currency</label>
<select name="currency" >
  <option value="USD">USD</option>
  <option  value="EGY">EGY</option>
</select>  <br>
    </div>
     <div class="card col-lg-5">
 <!-- <img src="..." class="card-img-top" alt="...">  -->
  <div class="card-body">
    <h5 class="card-title">T-shirt</h5>
     <label>Select Quantity</label>
   <input type="number" name="t-shirt" placeholder="select quantity" min=0 value=0>
  </div>
</div>

 <div class="card col-lg-5" >
  <!--<img src="..." class="card-img-top" alt="...">  -->
  <div class="card-body">
    <h5 class="card-title">Jacket</h5>
       <label>Select Quantity</label>
    <input type="number" name="jacket" placeholder="select quantity" min=0 value=0>
  </div>
</div>
 <div class="card col-lg-5" >
 <!-- <img src="..." class="card-img-top" alt="..."> -->
  <div class="card-body">
    <h5 class="card-title">Shoes</h5>
    <label>Select Quantity</label>
   <input type="number" name="shoes" placeholder="select quantity" min=0 value=0>
  </div>
</div>
 <div class="card col-lg-5" >
  <!--<img src="..." class="card-img-top" alt="...">    -->
  <div class="card-body">
    <h5 class="card-title">Pants</h5>
     <label>Select Quantity</label>
    <input type="number" name="pants" placeholder="select quantity" min=0 value=0>
  </div>
</div>
   <br>
<input type="submit" value="Get Bill" class="btn btn-primary">
 </form>
    </div>
<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
