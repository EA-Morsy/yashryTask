<?php
/* Smarty version 3.1.34-dev-7, created on 2020-10-28 22:02:51
  from 'C:\Users\Eman Morsi\Desktop\yashry\views\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f99dc7bdb79a9_74235616',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'add4c09d6f70b7a05f06e90faa33dc4245ffe015' => 
    array (
      0 => 'C:\\Users\\Eman Morsi\\Desktop\\yashry\\views\\index.tpl',
      1 => 1603918965,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f99dc7bdb79a9_74235616 (Smarty_Internal_Template $_smarty_tpl) {
?><form>
<select name="cars" id="cars">
  <option value="USD">USD</option>
  <option value="EGY">EGY</option>
</select>
<input type="text" placeholder="enter what you want " >
<input type="submit" value="enter">

</form><?php }
}
