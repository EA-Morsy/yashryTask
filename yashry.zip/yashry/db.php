<?php
include_once('cred.php');
//used singleton design pattern
class Db
{
    private static $instance;
    private function __construct()
    {
    }
    public static function getConnection()
    {
        if (self::$instance === null) {

            self::$instance = new PDO("mysql:host=" . host . ";dbname=" . dbName, username, password);
            self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
           
        }
        return self::$instance;
    }
}


