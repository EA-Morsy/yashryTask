<?php
/* Smarty version 3.1.34-dev-7, created on 2020-10-31 01:20:52
  from 'C:\xampp\htdocs\yashry\views\bill.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f9cade4319b46_18600685',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3fa5d9d28b9cdb084c586ee79e3c82cc5a902b4f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\yashry\\views\\bill.tpl',
      1 => 1604103632,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f9cade4319b46_18600685 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="../public/css/style2.css">
<title></title>
</head>
<body>




<div class="card bill" style="width: 18rem; margin:0 auto; margin-top:50px;" >
  
  <div class="card-body">
    <h3 class="card-title" align="center">YASHRY</h3>
        <h5>Subtotal:&nbsp; <spam style="font-size:15"><?php echo $_smarty_tpl->tpl_vars['curr']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['subtotal']->value;?>
</spam> </h5>
 <h5>Taxes :&nbsp; <spam style="font-size:15"><?php echo $_smarty_tpl->tpl_vars['curr']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['taxes']->value;?>
</spam></h5>                                           
 
 <?php if (!empty($_smarty_tpl->tpl_vars['discounts']->value)) {?>
 <h5>Discounts : </h5>
 <ul>
 <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['discounts']->value, 'value', false, 'key');
$_smarty_tpl->tpl_vars['value']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->do_else = false;
?>
     <li><?php echo $_smarty_tpl->tpl_vars['key']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['curr']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value;?>
 </li>
   <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
   </ul>
   <?php }?>
 <h5>Total:&nbsp; <spam style="font-size:15"><?php echo $_smarty_tpl->tpl_vars['curr']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['total']->value;?>
</spam> </h5>
 <a href="../index.php" aligh="center" style="margin:0 auto;" class="btn btn-primary">Back</a>
  </div>
</div>


 
 
 
<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
