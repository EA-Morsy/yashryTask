<?php
    require_once ('../libs/Smarty.class.php');
   require_once("../controllers/productContr.php");
   
function dynamic_page()
{
    if(isset($_GET['action']))
    {
        $action=$_GET['action'];
    }
    else
    {
        $action="";
    }
    
    switch($action){
            
          case 'getbill':
            if($_SERVER['REQUEST_METHOD']=="POST")
            {
             $currency=$_POST['currency'];
             if($currency=="USD")
             {
                 $curr=USD;
             }
             else 
             $curr=EGY;
             
             $t_shirt=$_POST['t-shirt'];
             $jacket=$_POST['jacket'];
             $pants=$_POST['pants'];
             $shoes=$_POST['shoes'];
             $listPurchase=["T-shirt"=>$t_shirt,"Jacket"=>$jacket,"Pants"=>$pants,"Shoes"=>$shoes];
             
             $productController=new ProductController();
             $purchases=$productController->getPurchases($listPurchase);
             $subTotal= $productController->calcSubTotal($purchases,$currency);
             $taxes=$productController->calcTaxes($subTotal);
             $discounts=$productController->showDiscounts($purchases,$currency);
             $total=$productController->calcTotal($subTotal,$taxes,$discounts);
             $smarty=new Smarty();
             $smarty->assign('curr' , $curr);
             $smarty->assign('subtotal',$subTotal);
             $smarty->assign('taxes',$taxes);
             $smarty->assign('discounts',$discounts);
             $smarty->assign('total',$total);
             $smarty->display("bill.tpl");
             }
          break;
          
            default:
            header("../index.php");
            break;
        }
        
   }
   
   dynamic_page();
    
    

