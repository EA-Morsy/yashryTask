<?php

require_once ('libs/Smarty.class.php');

$smarty=new Smarty();

$smarty->display("views/index.tpl");

