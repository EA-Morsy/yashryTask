<?php

require_once("../db.php");
class Product
{
    private $id;
    private $type;
    private $usd;
    private $egy;


    public function setId($id)
    {
        $this->id = $id;
    }

    public function setType($type)
    {
        $this->type = $type;
    }

    public function setUsd($usd)
    {
        $this->usd = $usd;
    }

    public function setEgy($egy)
    {
        $this->egy = $egy;
    }
    public function getType()
    {
        return $this->type;
    }
    public function getUsd()
    {
        return $this->usd;
    }
    public function getEgy()
    {
        return $this->egy;
    }
    public function getId()
    {
        return $this->id;
    }

    
  
}
