<?php      
  
  require_once("product.php");
class ProductDao
{
    //return price of specific item based on selected currency
      public function getPrice($type,$currency)
    {
      
        if($currency=="USD")
        {
            $sql="SELECT usd as price FROM product WHERE type='$type'";
        } else
          $sql="SELECT egy as price FROM product WHERE type='$type'";
          
        $db=Db::getConnection();
        $stmt=$db->prepare($sql);
        $stmt->execute();
        $result=$stmt->fetch();
        return $result['price'];

       
    }
}
